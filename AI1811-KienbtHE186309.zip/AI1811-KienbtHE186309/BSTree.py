class Bird:
    def __init__(self, xType, xRate, xWing):
        self.type = xType
        self.rate = xRate
        self.wing = xWing
        self.left = None
        self.right = None

class BSTree:
    def __init__(self):
        self.root = None

    def f0(self):
        return "He186309"

    def insert(self, xType, xRate, xWing):
        if xType[0] == 'B' or xRate > 10:
            return
        new_bird = Bird(xType, xRate, xWing)
        if self.root is None:
            self.root = new_bird
        else:
            self._insert_helper(self.root, new_bird)

    def _insert_helper(self, root, new_bird):
        if new_bird.rate < root.rate:
            if root.left is None:
                root.left = new_bird
            else:
                self._insert_helper(root.left, new_bird)
        else:
            if root.right is None:
                root.right = new_bird
            else:
                self._insert_helper(root.right, new_bird)

    def f1(self):
        self.insert("A", 5, 9)
        self.insert("E", 2, 5)
        self.insert("D", 8, 6)
        self.insert("F", -6, 7)
        self.insert("X", 4, 5)
        self.insert("Y", 6, -7)
        self._in_order_traversal(self.root)
        print()

    def _in_order_traversal(self, root):
        if root:
            self._in_order_traversal(root.left)
            print(f"({root.type},{root.rate},{root.wing})", end=" ")
            self._in_order_traversal(root.right)

    def f2(self):
        self._pre_order_traversal_wing(self.root)
        print()

    def _pre_order_traversal_wing(self, root):
        if root:
            if 4 <= root.wing <= 10:
                print(f"({root.type},{root.rate},{root.wing})", end=" ")
            self._pre_order_traversal_wing(root.left)
            self._pre_order_traversal_wing(root.right)

    def f3(self):
        self._breadth_first_traversal_odd(self.root)
        print()

    def _breadth_first_traversal_odd(self, root):
        queue = [root]
        odd_position = True
        while queue:
            level_size = len(queue)
            for _ in range(level_size):
                node = queue.pop(0)
                if odd_position:
                    print(f"({node.type},{node.rate},{node.wing})", end=" ")
                if node.left:
                    queue.append(node.left)
                if node.right:
                    queue.append(node.right)
            odd_position = not odd_position

    def f4(self):
        self._post_order_traversal_wing_rate(self.root)
        print()

    def _post_order_traversal_wing_rate(self, root):
        if root:
            self._post_order_traversal_wing_rate(root.left)
            self._post_order_traversal_wing_rate(root.right)
            if root.wing <= 4 and root.rate > 6:
                print(f"({root.type},{root.rate},{root.wing})", end=" ")

    def f5(self):
        self._in_order_traversal_type(self.root)
        print()

    def _in_order_traversal_type(self, root):
        if root:
            self._in_order_traversal_type(root.left)
            if root.type[0] == 'A' or root.type[0] == 'C':
                print(f"({root.type},{root.rate},{root.wing})", end=" ")
            self._in_order_traversal_type(root.right)

    def f6(self):
        self._delete_ith_node_in_order(self.root, 3)
        self._in_order_traversal(self.root)
        print()

    def _delete_ith_node_in_order(self, root, i):
        if root is None:
            return (None, i)
        (root.left, i) = self._delete_ith_node_in_order(root.left, i)
        if i == 0:
            return (root.right, i - 1)
        i -= 1
        (root.right, i) = self._delete_ith_node_in_order(root.right, i)
        return (root, i)

    def f7(self):
        self._delete_ith_node_post_order(self.root, 6)
        self._in_order_traversal(self.root)
        print()

    def _delete_ith_node_post_order(self, root, i):
        if root is None:
            return (None, i)
        (root.left, i) = self._delete_ith_node_post_order(root.left, i)
        (root.right, i) = self._delete_ith_node_post_order(root.right, i)
        if i == 0:
            return (root.left, i - 1)
        i -= 1
        return (root, i)

    def _in_order_traversal(self, root):
        if root:
            self._in_order_traversal(root.left)
            print(f"({root.type},{root.rate},{root.wing})", end=" ")
            self._in_order_traversal(root.right)

    def f8(self):
        height = self._get_height_pre_order(self.root, 4)
        self._set_height(self.root, height)
        self._in_order_traversal(self.root)
        print()

    def _get_height_pre_order(self, root, k):
        if root is None or k == 0:
            return 0
        left_height = self._get_height_pre_order(root.left, k - 1)
        right_height = self._get_height_pre_order(root.right, k - 1)
        return max(left_height, right_height) + 1

    def _set_height(self, root, height):
        if root is None:
            return
        self._set_height(root.left, height - 1)
        root.wing = height
        self._set_height(root.right, height - 1)

    def f9(self):
        height = self._get_height_in_order(self.root, 6)
        self._set_height(self.root, height)
        self._in_order_traversal(self.root)
        print()

    def _get_height_in_order(self, root, k):
        if root is None or k == 0:
            return 0
        left_height = self._get_height_in_order(root.left, k - 1)
        if left_height != 0:
            return left_height
        if k == 1:
            return 1
        return self._get_height_in_order(root.right, k - 1)

    def f10(self):
        self._rotate_first_node_with_two_children(self.root)
        self._in_order_traversal(self.root)
        print()

    def _rotate_first_node_with_two_children(self, root):
        if root is None:
            return
        self._rotate_first_node_with_two_children(root.left)
        self._rotate_first_node_with_two_children(root.right)
        if root.left and root.right and root.rate < 5:
            temp = root.left
            root.left = temp.right
            temp.right = root
            self.root = temp

    def f11(self):
        self._rotate_first_node_with_right_son(self.root)
        self._in_order_traversal(self.root)
        print()

    def _rotate_first_node_with_right_son(self, root):
        if root is None:
            return
        self._rotate_first_node_with_right_son(root.left)
        self._rotate_first_node_with_right_son(root.right)
        if root.right and root.rate > 7:
            temp = root.right
            root.right = temp.left
            temp.left = root
            self.root = temp

bst = BSTree()
bst.f1()  # f1
bst.f2()  # f2
bst.f3()  # f3
bst.f4()  # f4
bst.f5()  # f5
bst.f6()  # f6
bst.f7()  # f7
bst.f8()  # f8
bst.f9()  # f9
bst.f10()  # f10
bst.f11()  # f11
