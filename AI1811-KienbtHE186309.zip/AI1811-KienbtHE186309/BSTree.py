from collections import deque
class Bird:
    def __init__(self, xType, xRate, xWing):
        self.type = xType
        self.rate = xRate
        self.wing = xWing

class TreeNode:
    def __init__(self, key, val):
        self.key = key
        self.val = val
        self.left = None
        self.right = None

class BSTree:
    def __init__(self):
        self.root = None

    def f0(self):
        return "Hexxxxxx"

    def f1(self):
        if not self.root:
            return ""
        return self._inorder(self.root)

    def _inorder(self, node):
        result = ""
        if node.left:
            result += self._inorder(node.left)
        result += f"({node.val.type},{node.val.rate},{node.val.wing})"
        if node.right:
            result += self._inorder(node.right)
        return result

    def f2(self):
        if not self.root:
            return ""
        return self._preorder_wing(self.root)

    def _preorder_wing(self, node):
        result = ""
        if node.val.wing >= 4 and node.val.wing <= 10:
            result += f"({node.val.type},{node.val.rate},{node.val.wing})"
        if node.left:
            result += self._preorder_wing(node.left)
        if node.right:
            result += self._preorder_wing(node.right)
        return result

    def insert(self, xType, xRate, xWing):
        if xType[0] != 'B' and xRate <= 10:
            new_bird = Bird(xType, xRate, xWing)
            if not self.root:
                self.root = TreeNode(xRate, new_bird)
            else:
                self._insert_helper(self.root, xRate, new_bird)

    def _insert_helper(self, node, key, val):
        if key < node.key:
            if node.left is None:
                node.left = TreeNode(key, val)
            else:
                self._insert_helper(node.left, key, val)
        elif key > node.key:
            if node.right is None:
                node.right = TreeNode(key, val)
            else:
                self._insert_helper(node.right, key, val)
    def f3(self):
        if not self.root:
            return ""
        
        result = ""
        level = 1
        queue = deque([(self.root, level)])

        while queue:
            node, node_level = queue.popleft()
            if node_level % 2 != 0:
                result += f"({node.val.type},{node.val.rate},{node.val.wing})"
            if node.left:
                queue.append((node.left, node_level + 1))
            if node.right:
                queue.append((node.right, node_level + 1))

        return result
    def f4(self):
        if not self.root:
            return ""
        return self._postorder_filter(self.root)

    def _postorder_filter(self, node):
        result = ""
        if node.left:
            result += self._postorder_filter(node.left)
        if node.right:
            result += self._postorder_filter(node.right)
        if node.val.wing <= 4 and node.val.rate > 6:
            result += f"({node.val.type},{node.val.rate},{node.val.wing})"
        return result
# Test the implementation
if __name__ == "__main__":
    bst = BSTree()
    bst.insert("A", 5, 9)
    bst.insert("E", 2, 5)
    bst.insert("D", 8, 6)
    bst.insert("F", -6, 7)
    bst.insert("X", 4, 5)
    bst.insert("Y", 6, -7)
    print("Output for f1:")
    print(bst.f1())

    bst = BSTree() 
    bst.insert("C1", 9, 2)
    bst.insert("D", 6, 2)
    bst.insert("F", 2, 3)
    bst.insert("Z", 8, 1)
    bst.insert("H", 1, 7)
    bst.insert("I", 3, 9)
    bst.insert("Z1", 7, 1)
    bst.insert("J", 5, 5)
    bst.insert("K", 4, 1)
    print("\nOutput for f2:")
    print(bst.f2())
    
    bst = BSTree()
    bst.insert("C", 8, 2)
    bst.insert("D", 6, 1)
    bst.insert("F", 2, 3)
    bst.insert("H", 1, 7)
    bst.insert("I", 3, 9)
    bst.insert("J", 5, 5)
    bst.insert("K", 4, 6)
    bst.insert("G", 7, 8)
    bst.insert("E", 9, 4)
    print("\nOutput for f3:")
    print(bst.f3())
    
    bst = BSTree()
    bst.insert("C", 8, 2)
    bst.insert("D", 6, 1)
    bst.insert("F", 2, 3)
    bst.insert("H", 1, 7)
    bst.insert("I", 3, 9)
    bst.insert("J", 5, 8)
    bst.insert("K", 4, 6)
    bst.insert("G", 7, 3)
    bst.insert("E", 9, 4)
    print("\nOutput for f4:")
    print(bst.f4())

